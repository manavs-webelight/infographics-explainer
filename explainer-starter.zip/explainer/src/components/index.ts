import {TitleCard} from './TitleCard';
import {Flow} from './Flow';
import {StatCard} from './StatCard';
import {BulletList} from './BulletList';
import {BarChart} from './BarChart';
export const registry: Record<string, React.FC<any>> = {
  title: TitleCard,
  flow: Flow,
  stat: StatCard,
  bullets: BulletList,
  chart: BarChart,
};
