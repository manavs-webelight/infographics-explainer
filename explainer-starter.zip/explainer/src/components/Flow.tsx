import {Layout} from './Layout';
import {theme} from '../theme';
import {useIn} from '../anim';
import {ArrowRight} from 'lucide-react';
const Step: React.FC<{label: string; i: number; n: number}> = ({label, i, n}) => {
  const a = useIn(10 + i * 14);
  const arrow = useIn(18 + i * 14);
  return (
    <>
      <div style={{background: theme.card, border: `3px solid ${theme.accent}`, borderRadius: 28, padding: '50px 40px', fontSize: 46, fontWeight: 700, textAlign: 'center', minWidth: 300, opacity: a, transform: `scale(${0.8 + 0.2 * a})`}}>
        <div style={{color: theme.accent, fontSize: 30, marginBottom: 12}}>STEP {i + 1}</div>
        {label}
      </div>
      {i < n - 1 && <ArrowRight size={72} color={theme.accent2} style={{opacity: arrow, transform: `translateX(${(1 - arrow) * -20}px)`}} />}
    </>
  );
};
export const Flow: React.FC<{title?: string; steps: string[]}> = ({title, steps}) => {
  const t = useIn(0);
  return (
    <Layout>
      {title && <div style={{fontSize: 64, fontWeight: 800, marginBottom: 80, opacity: t}}>{title}</div>}
      <div style={{display: 'flex', alignItems: 'center', gap: 30, justifyContent: 'center'}}>
        {steps.map((s, i) => <Step key={i} label={s} i={i} n={steps.length} />)}
      </div>
    </Layout>
  );
};
