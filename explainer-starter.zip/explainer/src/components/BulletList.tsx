import {Layout} from './Layout';
import {theme} from '../theme';
import {useIn} from '../anim';
import {CheckCircle2} from 'lucide-react';
const Item: React.FC<{text: string; i: number}> = ({text, i}) => {
  const a = useIn(14 + i * 16);
  return (
    <div style={{display: 'flex', alignItems: 'center', gap: 28, fontSize: 56, marginBottom: 40, opacity: a, transform: `translateX(${(1 - a) * 60}px)`}}>
      <CheckCircle2 size={64} color={theme.good} /> {text}
    </div>
  );
};
export const BulletList: React.FC<{title: string; items: string[]}> = ({title, items}) => {
  const t = useIn(0);
  return (
    <Layout>
      <div style={{fontSize: 72, fontWeight: 800, marginBottom: 70, opacity: t}}>{title}</div>
      {items.map((it, i) => <Item key={i} text={it} i={i} />)}
    </Layout>
  );
};
