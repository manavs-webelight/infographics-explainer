import {spring, useCurrentFrame, useVideoConfig} from 'remotion';
// 0 -> 1 spring starting after `delay` frames
export const useIn = (delay = 0) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  return spring({frame: frame - delay, fps, config: {damping: 200}});
};
