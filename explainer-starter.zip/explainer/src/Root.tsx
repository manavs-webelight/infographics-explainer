import {Composition} from 'remotion';
import {Video, totalFrames} from './Video';
export const Root: React.FC = () => (
  <Composition id="Video" component={Video} durationInFrames={totalFrames()} fps={30} width={1920} height={1080} />
);
