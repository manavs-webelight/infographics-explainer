import {TransitionSeries, linearTiming} from '@remotion/transitions';
import {fade} from '@remotion/transitions/fade';
import {Fragment} from 'react';
import data from './scenes.json';
import {registry} from './components';
export const T = 12; // transition frames
export const totalFrames = () =>
  data.scenes.reduce((s, x) => s + x.durationInFrames, 0) - T * (data.scenes.length - 1);
export const Video: React.FC = () => (
  <TransitionSeries>
    {data.scenes.map((s: any, i) => {
      const Comp = registry[s.type];
      return (
        <Fragment key={i}>
          {i > 0 && <TransitionSeries.Transition presentation={fade()} timing={linearTiming({durationInFrames: T})} />}
          <TransitionSeries.Sequence durationInFrames={s.durationInFrames}>
            <Comp {...s} />
          </TransitionSeries.Sequence>
        </Fragment>
      );
    })}
  </TransitionSeries>
);
